Part1

task2:
- Why is a linked list natural for representing mutations?
    A linked list is a linear data structure made of nodes, where each node stores data and a pointer (reference) to the next node. Linked list elements are connected by pointers. This is famailar to mutations. DNA often requires insertions or deletions at positions in the middle of the sequence. A linked list can modify node connections directly without shifting large numbers of elements, making it highly suitable for modeling mutations.

DNA sequences are naturally modelled as linked lists of nucleotides (enabling efficient insertions and deletions that represent mutations)


- What is the cost of `insert_nucleotide` at position k in a linked list vs. in a Python string?
    链表想访问第 k 个核苷酸，必须从头开始走到第 k 个节点，后插入；python字符串是不可以改变的，需要先索引位置，再复制前半部分插入新字符，然后复制后半部分。链表的代价主要是遍历，字符串的代价主要是复制。
A linked list must traverse from the head to reach the k‑th nucleotide before performing an insertion at that position.
A Python string is immutable, so you must first locate the index, then copy the prefix, insert the new character, and finally copy the suffix.
The cost for a linked list comes mainly from traversal, while the cost for a string comes mainly from copying.

- When does the linked list underperform？
    当整体长度超长，需要频繁寻找靠后的指定位置时
    When the overall sequence becomes very long and you frequently need to access positions near the end.

task3:
- What information must a Mutation object store to be undoable?
    把序列恢复到突变之前的状态，需要储存突变位置，突变类型，突变前的碱基和突变后的碱基
To restore the sequence to its state before the mutation, you need to store the mutation position, the mutation type, the original base, and the mutated base.

- Is it sufficient to store the mutation type and position, or do you need more?
    Not enough. if we only store the mutation type and position, the program don't know what base should recover or delete.

Task4：
The current BST implementation uses sequence_id as the key for ordering and searching. A more biologically useful alternative would be to use species_name (the organism from which the sequence originates).

What it would enable:

1. Efficient Species-Based Queries : Currently, find_by_species() performs a full tree traversal (O(n)) to locate all sequences for a given species. If species_name were the key, sequences from the same species would be clustered together, enabling O(log n + k) retrieval where k is the number of sequences for that species.
2. Biologically Relevant Organization : In genetic research, sequences are often analyzed in the context of their species. Grouping by species makes it easier to compare sequences within the same organism or across related species.
3. Range Queries : You could efficiently find all sequences from species within a specific alphabetical range (e.g., all species starting with "A" through "H"), which is useful for biodiversity studies.
4. Ordered Traversal by Evolutionary Relationship : While not perfect, alphabetical ordering by species name can sometimes reflect taxonomic relationships, making in-order traversal more biologically meaningful.
Implementation Consideration : Since multiple sequences can belong to the same species, the BST would need to handle duplicate keys—either by storing multiple sequences per node or using a secondary structure like a linked list or another BST at each species node.

Part2

p2t1
Linked List Efficiency Impact
Problems:

1. No Random Access

    Can't jump to position directly

    Must walk from head every time → O(n) per access

2. Nested Loop Overhead
text

while current is not None:
    for mutation in mutations:    # scans all mutations for each node
        if mutation.position == pos:
            count++

    O(L × M) where L = length, M = mutations

    Very slow for long sequences

3. Bubble Sort

    O(K²) sorting where K = number of hotspots

    Python's sort would be O(K log K) - much faster

4. Poor Cache Performance

    Nodes scattered in memory

    Arrays would be faster (contiguous memory)

p2t2

DP Table Walkthrough & Stack Traceback
 Example Sequences
- Sequence A: GATTA (length 5)
- Sequence B: GCTAA (length 5)

 DP Table

      G  C  T  A  A
   0  1  2  3  4  5
G  1  0  1  2  3  4
A  2  1  1  2  2  3
T  3  2  2  1  2  3
T  4  3  3  2  2  3
A  5  4  4  3  2  2

Traceback Steps

From bottom-right (5,5) back to (0,0):

1. (5,5): A=A -> MATCH (A,A)
2. (4,4): T!=A -> SUBSTITUTE (T,A)
3. (3,3): T=T -> MATCH (T,T)
4. (2,2): A!=C -> SUBSTITUTE (A,C)
5. (1,1): G=G -> MATCH (G,G)

Stack Contents (bottom to top):

MATCH (G,G)
SUBSTITUTE (A,C)
MATCH (T,T)
SUBSTITUTE (T,A)
MATCH (A,A)  <- top


After popping, we get correct alignment:

G A T T A
G C T A A

Why Stack, Not Queue?

Backtracking goes backwards(end to start), but output needs to be forwards (start to end).

Stack (LIFO) - Last In First Out, automatically reverses order:

   Backtracking order (end->start): (A,A)->(T,A)->(T,T)->(A,C)->(G,G)
   Push order:                      push1->push2->push3->push4->push5
   Pop order:                       pop5->pop4->pop3->pop2->pop1
   Output (start->end):             (G,G)->(A,C)->(T,T)->(T,A)->(A,A) [CORRECT]

Queue (FIFO) - First In First Out, keeps reverse order:

   Enqueue order: push1->push2->push3->push4->push5
   Dequeue order: pop1->pop2->pop3->pop4->pop5
   Output:        (A,A)->(T,A)->(T,T)->(A,C)->(G,G) [WRONG - Reversed]

Summary

Stack works for traceback because:
- Traceback builds path backwards
- LIFO automatically reverses the order
- No extra reversal step needed
- O(1) push/pop, simple and efficient



task3:
- Which MST algorithm did you implement and why?
 I use Kruskal's Algorithm. I chose this algorithm because 
（1）The graph is stored as an edge list called self.edges, where each edge is this format:[species1, species2, distance]. Kruskal's algorithm works directly on edge lists — the first step is simply sorting all edges by weight, which can be done with Python's built-in sorted() function.
（2） Phylogenetic trees typically have edges E close to the number of species V, making them sparse graphs. Kruskal's O(E log E) complexity performs well in this scenario.
（3） If I had chosen Prim's algorithm, I would need to convert the edge list to an adjacency list. Kruskal avoids this extra work.

- What is its time complexity?
The time complexity of Kruskal's algorithm is O(E log E), where E is the number of edges.

- What does the MST tell a biologist that the full distance graph does not?
The MST tells a biologist the most parsimonious evolutionary tree, while the full distance graph shows all possible evolutionary relationships.



Task4:
- Does the empirical curve confirm O(n²)?
Yes,I calculated the average value,the average ratio of actual time to theoretical O(n²) is 1.12, which is very close to the ideal value of 1.0.

- At what length L does it become noticeably slow?
The edit distance computation becomes noticeably slow at L = 5000, where it takes approximately 2.4 seconds. At L = 20000, it takes around 124 seconds, which is impractical for interactive use. 