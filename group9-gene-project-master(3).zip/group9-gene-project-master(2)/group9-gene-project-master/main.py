# 序列链表核心类，存储 DNA 字符串、碱基链表、突变记录，生成 / 加载数据集时创建序列对象
from src.models.sequence import Sequence
# 枚举类：碱基 (A/T/G/C)、序列类型 DNA、突变类型替换，规范数据格式
from src.models.enums import Base, SequenceType, MutationType
# 突变实体类，保存突变位点、原碱基、突变碱基，加载 CSV 突变数据使用
from src.models.mutation import Mutation
# 二叉搜索树 BST，Task6 要求加载完序列后存入 BST，提供按物种查找序列功能
from src.models.bst import SequenceLibrary
# 进化关系图，加载 distance CSV 构建物种 / 序列距离边，后续求 MST
from src.models.graph import PhylogeneticGraph
# Part2 Task1 编辑距离（Levenshtein）专用导入
from src.models.edit_distance import compute_edit_distance, traceback, get_alignment_from_stack
# Part2 Task2 突变热点检测专用导入
from src.models.hotspot_detection import detect_hotspots, detect_hotspots_from_multiple_alignments
from src.models.data_generator import generate_all_datasets
from src.models.data_loader import load_all_datasets

# task6
def main():
    print("=" * 70)
    print("Bioinformatics Analysis Tool - Comprehensive Test")
    print("=" * 70)

    print("\n" + "=" * 70)
    print("Part 1 Task 6: Generate and Load Dataset")
    print("=" * 70)
    
    generate_all_datasets()
    #调用数据集生成函数（你之前的 data_generator.py），自动创建 datasets 文件夹，生成 3 份 CSV 文件：序列、突变、进化距离，满足 Task6 要求：10 条序列、3–5 物种、每条 3–5 突变、至少 15 条距离边。
    
    sequences_dict, mutations_list, graph = load_all_datasets()
    # 加载刚生成的 CSV 数据集，调用 data_loader 封装好的加载函数，一次性返回 3 组数据：
    # 把字典里所有 Sequence 对象提取出来，存入列表 sequences，后续循环插入 BST 时，遍历列表更方便。（下）
    sequences = []
    for seq_id in sequences_dict:
        sequences.append(sequences_dict[seq_id])
    
    # 创建二叉搜索树 BST 容器对象，对应 Task6 要求构建 BST 存储所有序列
    sequence_library = SequenceLibrary()
    # while 循环遍历全部序列，逐条插入 BST 树结构
    i = 0
    while i < len(sequences):
        sequence_library.insert(sequences[i])
        i = i + 1
    #     加载完成后的信息打印，给用户反馈加载结果：
    #       一共多少条序列存入二叉搜索树
    #       识别到多少个不同物种
    #       进化图中一共有多少组物种 / 序列距离关系（边）
    print("\nLoaded " + str(len(sequences)) + " sequences into BST")
    print("Loaded " + str(len(graph.species)) + " species into phylogenetic graph")
    print("Loaded " + str(len(graph.edges)) + " evolutionary relationships")

#   part2task1
    print("\n" + "=" * 70)
    print("Part 2 Task 1: Edit Distance (Levenshtein)")
    print("=" * 70)
    
    seq1 = Sequence("seq1", "Test1", SequenceType.DNA)
    seq2 = Sequence("seq2", "Test2", SequenceType.DNA)
    
    bases1 = "ATGC"
    j = 0
    while j < len(bases1):
        seq1.insert_nucleotide(seq1.size, Base[bases1[j]])
        j = j + 1
    
    bases2 = "AAGC"
    j = 0
    while j < len(bases2):
        seq2.insert_nucleotide(seq2.size, Base[bases2[j]])
        j = j + 1
    
    print("\nSequence 1: " + seq1.get_sequence_string())
    print("Sequence 2: " + seq2.get_sequence_string())
    
    dp = compute_edit_distance(seq1, seq2)
    distance, stack = traceback(seq1, seq2, dp)
    print("\nEdit Distance: " + str(distance))
    
    aligned_a, aligned_b, operations = get_alignment_from_stack(stack)
    print("\nAlignment:")
    print("  " + aligned_a)
    
    marks = ""
    k = 0
    while k < len(operations):
        if operations[k] == 'MATCH':
            marks = marks + '|'
        else:
            marks = marks + '*'
        k = k + 1
    print("  " + marks)
    print("  " + aligned_b)
    
    print("\nOperations (from stack):")
    k = 0
    while k < len(operations):
        print("  Step " + str(k) + ": " + operations[k])
        k = k + 1



#   part2task2
    print("\n" + "=" * 70)
    print("Part 2 Task 2: Mutation Hotspot Detection")
    print("=" * 70)
    
    human_seqs = sequence_library.find_by_species("Homo sapiens")
    if len(human_seqs) > 0:
        hotspots = detect_hotspots_from_multiple_alignments(human_seqs, threshold=0.3)
        
        print("\nAnalyzing " + str(len(human_seqs)) + " sequences from Homo sapiens")
        print("Found " + str(len(hotspots)) + " mutation hotspots:")
        
        limit = 5
        if len(hotspots) < limit:
            limit = len(hotspots)
        k = 0
        while k < limit:
            hotspot = hotspots[k]
            print("\n  Position " + str(hotspot['position']) + ":")
            print("    Diversity: " + "{:.3f}".format(hotspot['diversity']))
            print("    Base Counts: " + str(hotspot['base_counts']))
            print("    Majority: " + hotspot['majority_base'] + ", Minority: " + hotspot['minority_base'])
            k = k + 1
    else:
        print("\nNo Homo sapiens sequences found in library")

if __name__ == "__main__":
    main()

print('程序运行成功')