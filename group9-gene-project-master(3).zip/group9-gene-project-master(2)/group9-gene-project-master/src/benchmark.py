import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import time
import random
import os
import csv
from src.models.sequence import Sequence
from src.models.enums import Base, SequenceType


def generate_random_sequence(length):
    bases = [Base.A, Base.T, Base.G, Base.C]
    seq = Sequence(f"seq_{length}", "test_species", SequenceType.DNA)
    for i in range(length):
        seq.insert_nucleotide(i, random.choice(bases))
    return seq


def benchmark_insertion(lengths=[50, 200, 1000, 5000, 20000], iterations=100):
    results = []
    print("=" * 60)
    print("Benchmark: Insertion Operations")
    print("-" * 60)
    print(f"{'Length':>6} {'Beginning(s)':>14} {'Middle(s)':>12} {'End(s)':>10}")
    print("-" * 60)
    
    for L in lengths:
        seq = generate_random_sequence(L)
        base = Base.A
        
        start = time.time()
        for _ in range(iterations):
            seq.insert_nucleotide(0, base)
            seq.delete_nucleotide(0)
        elapsed_beginning = (time.time() - start) / iterations
        
        mid = L // 2
        start = time.time()
        for _ in range(iterations):
            seq.insert_nucleotide(mid, base)
            seq.delete_nucleotide(mid)
        elapsed_middle = (time.time() - start) / iterations
        
        start = time.time()
        for _ in range(iterations):
            seq.insert_nucleotide(L, base)
            seq.delete_nucleotide(L)
        elapsed_end = (time.time() - start) / iterations
        
        results.append((L, elapsed_beginning, elapsed_middle, elapsed_end))
        print(f"{L:6d} {elapsed_beginning:14.6f} {elapsed_middle:12.6f} {elapsed_end:10.6f}")
    
    return results


def benchmark_find_subsequence(lengths=[50, 200, 1000, 5000, 20000], iterations=100):
    results = []
    print("\n" + "=" * 60)
    print("Benchmark: Subsequence Search")
    print("-" * 60)
    print(f"{'Length':>6} {'Beginning(s)':>14} {'End(s)':>12}")
    print("-" * 60)
    
    for L in lengths:
        seq = generate_random_sequence(L)
        seq_str = seq.get_sequence_string()
        
        pattern = seq_str[:5]
        start = time.time()
        for _ in range(iterations):
            seq.find_subsequence(pattern)
        elapsed_beginning = (time.time() - start) / iterations
        
        pattern_end = seq_str[-5:]
        start = time.time()
        for _ in range(iterations):
            seq.find_subsequence(pattern_end)
        elapsed_end = (time.time() - start) / iterations
        
        results.append((L, elapsed_beginning, elapsed_end))
        print(f"{L:6d} {elapsed_beginning:14.6f} {elapsed_end:12.6f}")
    
    return results


def benchmark_edit_distance(lengths=[50, 200, 1000, 5000]):
    results = []
    print("\n" + "=" * 60)
    print("Benchmark: Edit Distance Computation (O(L²))")
    print("-" * 60)
    print(f"{'Length':>6} {'Distance':>10} {'Time(s)':>14}")
    print("-" * 60)
    
    for L in lengths:
        seq1 = generate_random_sequence(L)
        seq2 = generate_random_sequence(L)
        
        s1 = seq1.get_sequence_string()
        s2 = seq2.get_sequence_string()
        
        start = time.time()
        m, n = len(s1), len(s2)
        dp = [[0] * (n + 1) for _ in range(m + 1)]
        for i in range(m + 1):
            dp[i][0] = i
        for j in range(n + 1):
            dp[0][j] = j
        for i in range(1, m + 1):
            for j in range(1, n + 1):
                if s1[i-1] == s2[j-1]:
                    dp[i][j] = dp[i-1][j-1]
                else:
                    dp[i][j] = 1 + min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1])
        dist = dp[m][n]
        elapsed = time.time() - start
        
        results.append((L, dist, elapsed))
        print(f"{L:6d} {dist:10d} {elapsed:14.6f}")
    
    return results


def plot_results(insert_results, search_results, edit_results):
    output_dir = "benchmark_results"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    if insert_results:
        L_vals = [x[0] for x in insert_results]
        axes[0].plot(L_vals, [x[1] for x in insert_results], 'o-', label='Beginning')
        axes[0].plot(L_vals, [x[2] for x in insert_results], 's-', label='Middle')
        axes[0].plot(L_vals, [x[3] for x in insert_results], '^-', label='End')
        axes[0].set_xlabel('Length')
        axes[0].set_ylabel('Time (s)')
        axes[0].set_title('Insertion Operations')
        axes[0].legend()
        axes[0].grid(True)
    
    if search_results:
        L_vals = [x[0] for x in search_results]
        axes[1].plot(L_vals, [x[1] for x in search_results], 'o-', label='Beginning')
        axes[1].plot(L_vals, [x[2] for x in search_results], 's-', label='End')
        axes[1].set_xlabel('Length')
        axes[1].set_ylabel('Time (s)')
        axes[1].set_title('Subsequence Search')
        axes[1].legend()
        axes[1].grid(True)
    
    if edit_results:
        L_vals = [x[0] for x in edit_results]
        axes[2].plot(L_vals, [x[2] for x in edit_results], 'o-', label='Time')
        axes[2].set_xlabel('Length')
        axes[2].set_ylabel('Time (s)')
        axes[2].set_title('Edit Distance (O(L²))')
        axes[2].legend()
        axes[2].grid(True)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'benchmark_results.png'), dpi=150)
    print(f"\nFigure saved as: benchmark_results/benchmark_results.png")
    
    with open(os.path.join(output_dir, 'insertion_results.csv'), 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Length', 'Beginning', 'Middle', 'End'])
        writer.writerows(insert_results)
    
    with open(os.path.join(output_dir, 'search_results.csv'), 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Length', 'Beginning', 'End'])
        writer.writerows(search_results)
    
    with open(os.path.join(output_dir, 'edit_distance_results.csv'), 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Length', 'Distance', 'Time'])
        writer.writerows(edit_results)
    
    print(f"CSV data saved to: benchmark_results/")


def run_all_benchmarks():
    print("Starting benchmarks...\n")
    
    insert_results = benchmark_insertion()
    search_results = benchmark_find_subsequence()
    edit_results = benchmark_edit_distance()
    
    print("\n" + "=" * 60)
    print("Benchmarks complete! Generating plots...")
    plot_results(insert_results, search_results, edit_results)