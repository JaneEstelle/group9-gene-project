import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os


def visualize_bst(bst, output_file='bst_visualization.png'):
    fig, ax = plt.subplots(figsize=(12, 8))
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis('off')
    
    if bst.root is None:
        plt.savefig(output_file, dpi=150)
        print(f"BST visualization saved to: {output_file}")
        return
    
    node_positions = {}
    
    def layout(node, x, y, width):
        if node is None:
            return
        node_positions[node.sequence.sequence_id] = (x, y)
        
        if node.left:
            ax.plot([x, x - width/2], [y - 5, y - 25], 'k-', linewidth=2)
            layout(node.left, x - width/2, y - 30, width/2)
        
        if node.right:
            ax.plot([x, x + width/2], [y - 5, y - 25], 'k-', linewidth=2)
            layout(node.right, x + width/2, y - 30, width/2)
    
    layout(bst.root, 50, 90, 40)
    
    for seq_id, (x, y) in node_positions.items():
        ax.add_patch(plt.Circle((x, y), 12, color='#3498db'))
        ax.text(x, y, seq_id, ha='center', va='center', color='white', 
                fontsize=9, fontweight='bold')
    
    ax.set_title('Sequence Library (BST)', fontsize=16, fontweight='bold', pad=20)
    
    output_dir = os.path.dirname(output_file)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    plt.savefig(output_file, dpi=150, bbox_inches='tight')
    print(f"BST visualization saved to: {output_file}")
    
    return output_file