import csv
import random
import os
from src.models.enums import Base, SequenceType, MutationType


def generate_random_dna_sequence(length):
    bases = ['A', 'T', 'G', 'C']
    return ''.join(random.choice(bases) for _ in range(length))


def mutate_sequence(seq_str, num_mutations):
    bases = ['A', 'T', 'G', 'C']
    seq_list = list(seq_str)
    mutations_made = []
    
    for _ in range(num_mutations):
        pos = random.randint(0, len(seq_list) - 1)
        original = seq_list[pos]
        new_base = random.choice([b for b in bases if b != original])
        seq_list[pos] = new_base
        mutations_made.append({
            'position': pos,
            'original_base': original,
            'new_base': new_base
        })
    
    return ''.join(seq_list), mutations_made


def generate_datasets(output_dir='datasets'):
    os.makedirs(output_dir, exist_ok=True)
    
    species = ['Homo sapiens', 'Pan troglodytes', 'Gorilla gorilla', 'Pongo abelii', 'Macaca mulatta']
    
    sequences = []
    mutations = []
    distances = []
    
    for sp_idx, species_name in enumerate(species):
        num_seqs = random.randint(2, 3)
        base_length = random.randint(20, 100)
        base_seq = generate_random_dna_sequence(base_length)
        
        for seq_idx in range(num_seqs):
            seq_id = f"seq_{sp_idx + 1:02d}_{seq_idx + 1:02d}"
            
            if seq_idx == 0:
                seq_str = base_seq
            else:
                num_muts = random.randint(3, 5)
                seq_str, mutations_made = mutate_sequence(base_seq, num_muts)
                
                for mut in mutations_made:
                    mutations.append({
                        'sequence_id': seq_id,
                        'mutation_type': 'SUBSTITUTION',
                        'position': mut['position'],
                        'original_base': mut['original_base'],
                        'new_base': mut['new_base']
                    })
            
            sequences.append({
                'sequence_id': seq_id,
                'species_name': species_name,
                'sequence_type': 'DNA',
                'sequence_string': seq_str
            })
    
    for i in range(len(species)):
        for j in range(i + 1, len(species)):
            sp1 = species[i]
            sp2 = species[j]
            
            if i == 0 and j == 1:
                dist = random.randint(2, 4)
            elif i == 0 and j == 2:
                dist = random.randint(3, 6)
            elif i == 1 and j == 2:
                dist = random.randint(2, 5)
            elif i == 3 and j == 4:
                dist = random.randint(2, 4)
            elif i <= 2 and j >= 3:
                dist = random.randint(15, 25)
            else:
                dist = random.randint(5, 20)
            
            distances.append({
                'species_a': sp1,
                'species_b': sp2,
                'distance': dist
            })
    
    with open(os.path.join(output_dir, 'sequences_dataset.csv'), 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['sequence_id', 'species_name', 'sequence_type', 'sequence_string'])
        writer.writeheader()
        writer.writerows(sequences)
    
    with open(os.path.join(output_dir, 'mutations_dataset.csv'), 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['sequence_id', 'mutation_type', 'position', 'original_base', 'new_base'])
        writer.writeheader()
        writer.writerows(mutations)
    
    with open(os.path.join(output_dir, 'evolutionary_distances_dataset.csv'), 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['species_a', 'species_b', 'distance'])
        writer.writeheader()
        writer.writerows(distances)
    
    print(f"Generated {len(sequences)} sequences across {len(species)} species")
    print(f"Generated {len(mutations)} mutations")
    print(f"Generated {len(distances)} evolutionary relationships")
    print(f"Files saved to: {output_dir}/")
    
    return sequences, mutations, distances


def load_datasets(input_dir='datasets'):
    sequences = []
    mutations = []
    distances = []
    
    with open(os.path.join(input_dir, 'sequences_dataset.csv'), 'r') as f:
        reader = csv.DictReader(f)
        sequences = list(reader)
    
    with open(os.path.join(input_dir, 'mutations_dataset.csv'), 'r') as f:
        reader = csv.DictReader(f)
        mutations = list(reader)
    
    with open(os.path.join(input_dir, 'evolutionary_distances_dataset.csv'), 'r') as f:
        reader = csv.DictReader(f)
        distances = list(reader)
    
    return sequences, mutations, distances