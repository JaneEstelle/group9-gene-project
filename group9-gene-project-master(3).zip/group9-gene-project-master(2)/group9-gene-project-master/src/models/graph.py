class PhylogeneticGraph:
    def __init__(self):
        self.species = []
        self.edges = []

    def add_species(self, species_name):
        if species_name not in self.species:
            self.species.append(species_name)

    def add_relationship(self, species1, species2, distance):
        self.add_species(species1)
        self.add_species(species2)
        
        for edge in self.edges:
            if (edge[0] == species1 and edge[1] == species2) or \
               (edge[0] == species2 and edge[1] == species1):
                edge[2] = distance
                return
        
        self.edges.append([species1, species2, distance])

    def get_distance(self, species1, species2):
        for edge in self.edges:
            if (edge[0] == species1 and edge[1] == species2) or \
               (edge[0] == species2 and edge[1] == species1):
                return edge[2]
        return None

    def get_all_species(self):
        return self.species.copy()

    def get_relationships(self):
        return [edge.copy() for edge in self.edges]

    def minimum_spanning_tree(self):
        mst = PhylogeneticGraph()
        
        for species in self.species:
            mst.add_species(species)
        
        if len(self.species) <= 1:
            return mst
        
        sorted_edges = sorted(self.edges, key=lambda x: x[2])
        
        parent = {species: species for species in self.species}
        
        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x
        
        def union(x, y):
            root_x = find(x)
            root_y = find(y)
            if root_x == root_y:
                return False
            parent[root_y] = root_x
            return True
        
        for species1, species2, distance in sorted_edges:
            if union(species1, species2):
                mst.add_relationship(species1, species2, distance)
                if len(mst.edges) == len(self.species) - 1:
                    break
        
        return mst

    def get_neighbors(self, species_name):
        neighbors = []
        for edge in self.edges:
            if edge[0] == species_name:
                neighbors.append(edge[1])
            elif edge[1] == species_name:
                neighbors.append(edge[0])
        return neighbors

    def get_total_weight(self):
        return sum(edge[2] for edge in self.edges)