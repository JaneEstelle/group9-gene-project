import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import matplotlib
matplotlib.use('TkAgg')
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import networkx as nx
from src.models.sequence import Sequence
from src.models.enums import Base, SequenceType
from src.models.bst import SequenceLibrary
from src.models.graph import PhylogeneticGraph
from src.models.edit_distance import compute_edit_distance, get_alignment_from_stack


class NucleotideViewer(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.configure(bg='#f0f0f0')
        
        ttk.Label(self, text="Sequence Viewer", font=('Arial', 12, 'bold')).pack(pady=5)
        
        self.canvas_frame = ttk.Frame(self)
        self.canvas_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.canvas = tk.Canvas(self.canvas_frame, bg='white', borderwidth=2, relief='sunken')
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        self.base_colors = {
            'A': '#FF6B6B',
            'T': '#4ECDC4',
            'G': '#45B7D1',
            'C': '#96CEB4'
        }
    
    def display_sequence(self, sequence):
        self.canvas.delete('all')
        if not sequence or sequence.head is None:
            return
        
        seq_str = sequence.get_sequence_string()
        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()
        
        if canvas_width < 10:
            canvas_width = 600
        if canvas_height < 10:
            canvas_height = 100
        
        node_width = min(30, canvas_width // max(len(seq_str), 1))
        node_height = 40
        spacing = 5
        total_width = len(seq_str) * (node_width + spacing)
        
        start_x = (canvas_width - total_width) // 2 + node_width // 2
        start_y = (canvas_height - node_height) // 2
        
        current = sequence.head
        idx = 0
        while current:
            x = start_x + idx * (node_width + spacing)
            y = start_y
            
            base = current.base.value
            color = self.base_colors.get(base, '#CCCCCC')
            
            self.canvas.create_oval(
                x - node_width // 2, y - node_height // 2,
                x + node_width // 2, y + node_height // 2,
                fill=color, outline='black', width=2
            )
            
            self.canvas.create_text(x, y, text=base, font=('Arial', 10, 'bold'), fill='white')
            
            if current.next:
                next_x = start_x + (idx + 1) * (node_width + spacing)
                self.canvas.create_line(
                    x + node_width // 2, y,
                    next_x - node_width // 2, y,
                    fill='gray', width=2, arrow=tk.LAST
                )
            
            idx += 1
            current = current.next


class MutationHistoryPanel(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.configure(bg='#f0f0f0')
        
        ttk.Label(self, text="Mutation History", font=('Arial', 12, 'bold')).pack(pady=5)
        
        self.history_list = scrolledtext.ScrolledText(self, height=10, width=40)
        self.history_list.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
    
    def display_history(self, sequence):
        self.history_list.delete('1.0', tk.END)
        if not sequence:
            return
        
        history = sequence.mutation_history()
        
        if len(history) == 0:
            self.history_list.insert(tk.END, "No mutations applied yet.\n")
            return
        
        for i, mutation in enumerate(reversed(history)):
            original = mutation.original_base.value if mutation.original_base else '-'
            new = mutation.new_base.value if mutation.new_base else '-'
            
            text = f"#{len(history) - i}: {mutation.mutation_type.value}\n"
            text += f"   Position: {mutation.position}\n"
            text += f"   Original: {original} -> New: {new}\n\n"
            
            self.history_list.insert(tk.END, text)


class PhylogeneticGraphPanel(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.configure(bg='#f0f0f0')
        
        ttk.Label(self, text="Phylogenetic Tree", font=('Arial', 12, 'bold')).pack(pady=5)
        
        self.figure = Figure(figsize=(5, 4), dpi=100)
        self.ax = self.figure.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.figure, self)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    def display_graph(self, graph, highlight_mst=False, mst_edges=None):
        self.ax.clear()
        
        G = nx.Graph()
        
        for species in graph.species:
            G.add_node(species)
        
        for edge in graph.edges:
            G.add_edge(edge[0], edge[1], weight=edge[2])
        
        pos = nx.spring_layout(G, seed=42, k=0.15)
        
        if highlight_mst and mst_edges:
            mst_edge_set = set()
            for edge in mst_edges:
                mst_edge_set.add((edge[0], edge[1]))
                mst_edge_set.add((edge[1], edge[0]))
            
            non_mst_edges = [(u, v) for u, v in G.edges() if (u, v) not in mst_edge_set]
            mst_edges_display = [(u, v) for u, v in G.edges() if (u, v) in mst_edge_set]
            
            nx.draw_networkx_nodes(G, pos, ax=self.ax, node_size=700, 
                                   node_color='lightblue', edgecolors='black')
            nx.draw_networkx_edges(G, pos, ax=self.ax, edgelist=non_mst_edges,
                                   edge_color='gray', alpha=0.3, width=1)
            nx.draw_networkx_edges(G, pos, ax=self.ax, edgelist=mst_edges_display,
                                   edge_color='red', alpha=1.0, width=2)
        else:
            nx.draw_networkx_nodes(G, pos, ax=self.ax, node_size=700,
                                   node_color='lightblue', edgecolors='black')
            nx.draw_networkx_edges(G, pos, ax=self.ax, edge_color='gray', width=1)
        
        nx.draw_networkx_labels(G, pos, ax=self.ax, font_size=8, font_weight='bold')
        
        edge_labels = {(u, v): f"{d['weight']:.1f}" for u, v, d in G.edges(data=True)}
        nx.draw_networkx_edge_labels(G, pos, ax=self.ax, edge_labels=edge_labels,
                                     font_size=7)
        
        self.ax.set_title("Phylogenetic Graph (MST in red)")
        self.figure.tight_layout()
        self.canvas.draw()


class ComparisonPanel(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.configure(bg='#f0f0f0')
        
        ttk.Label(self, text="Sequence Comparison", font=('Arial', 12, 'bold')).pack(pady=5)
        
        self.seq1_label = ttk.Label(self, text="Sequence 1:")
        self.seq1_label.pack(anchor='w', padx=5)
        
        self.seq1_text = scrolledtext.ScrolledText(self, height=3, width=50)
        self.seq1_text.pack(fill=tk.X, padx=5)
        
        self.seq2_label = ttk.Label(self, text="Sequence 2:")
        self.seq2_label.pack(anchor='w', padx=5)
        
        self.seq2_text = scrolledtext.ScrolledText(self, height=3, width=50)
        self.seq2_text.pack(fill=tk.X, padx=5)
        
        self.distance_label = ttk.Label(self, text="Edit Distance: -", font=('Arial', 10, 'bold'))
        self.distance_label.pack(pady=5)
        
        self.alignment_label = ttk.Label(self, text="Alignment:")
        self.alignment_label.pack(anchor='w', padx=5)
        
        self.alignment_text = scrolledtext.ScrolledText(self, height=5, width=50)
        self.alignment_text.pack(fill=tk.BOTH, expand=True, padx=5)
    
    def compare_sequences(self, seq1, seq2):
        self.seq1_text.delete('1.0', tk.END)
        self.seq2_text.delete('1.0', tk.END)
        self.alignment_text.delete('1.0', tk.END)
        
        if not seq1 or not seq2:
            self.distance_label.config(text="Edit Distance: -")
            return
        
        seq1_str = seq1.get_sequence_string()
        seq2_str = seq2.get_sequence_string()
        
        self.seq1_text.insert(tk.END, seq1_str)
        self.seq2_text.insert(tk.END, seq2_str)
        
        distance, stack = compute_edit_distance(seq1, seq2)
        self.distance_label.config(text=f"Edit Distance: {distance}")
        
        aligned_a, aligned_b, operations = get_alignment_from_stack(stack)
        
        alignment_display = ""
        for i in range(len(aligned_a)):
            op = operations[i]
            if op == 'MATCH':
                alignment_display += "|"
            elif op == 'SUBSTITUTION':
                alignment_display += "*"
            elif op == 'INSERTION':
                alignment_display += "^"
            elif op == 'DELETION':
                alignment_display += "v"
        
        self.alignment_text.insert(tk.END, f"{aligned_a}\n{alignment_display}\n{aligned_b}\n\n")
        self.alignment_text.insert(tk.END, "Operations:\n")
        for i, op in enumerate(operations):
            self.alignment_text.insert(tk.END, f"  {i}: {op}\n")


class MainGUI(tk.Tk):
    def __init__(self, sequences=None, graph=None):
        super().__init__()
        self.title("Bioinformatics Analysis Tool")
        self.geometry("1200x800")
        
        self.sequences = sequences if sequences else []
        self.graph = graph if graph else PhylogeneticGraph()
        self.sequence_library = SequenceLibrary()
        
        self._setup_menu()
        self._setup_panels()
        self._load_initial_data()
    
    def _setup_menu(self):
        menubar = tk.Menu(self)
        
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Generate Dataset", command=self._generate_dataset)
        file_menu.add_command(label="Load Dataset", command=self._load_dataset)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.quit)
        menubar.add_cascade(label="File", menu=file_menu)
        
        analysis_menu = tk.Menu(menubar, tearoff=0)
        analysis_menu.add_command(label="Compute MST", command=self._compute_mst)
        analysis_menu.add_command(label="Compare Sequences", command=self._compare_sequences_dialog)
        menubar.add_cascade(label="Analysis", menu=analysis_menu)
        
        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label="About", command=self._show_about)
        menubar.add_cascade(label="Help", menu=help_menu)
        
        self.config(menu=menubar)
    
    def _setup_panels(self):
        main_frame = ttk.Frame(self)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        left_frame = ttk.Frame(main_frame, width=400)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=(0, 5))
        
        right_frame = ttk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        top_left = ttk.Frame(left_frame)
        top_left.pack(fill=tk.BOTH, expand=True, pady=(0, 5))
        
        bottom_left = ttk.Frame(left_frame)
        bottom_left.pack(fill=tk.BOTH, expand=True)
        
        self.nucleotide_viewer = NucleotideViewer(top_left)
        self.nucleotide_viewer.pack(fill=tk.BOTH, expand=True)
        
        self.mutation_panel = MutationHistoryPanel(bottom_left)
        self.mutation_panel.pack(fill=tk.BOTH, expand=True)
        
        top_right = ttk.Frame(right_frame)
        top_right.pack(fill=tk.BOTH, expand=True, pady=(0, 5))
        
        bottom_right = ttk.Frame(right_frame)
        bottom_right.pack(fill=tk.BOTH, expand=True)
        
        self.graph_panel = PhylogeneticGraphPanel(top_right)
        self.graph_panel.pack(fill=tk.BOTH, expand=True)
        
        self.comparison_panel = ComparisonPanel(bottom_right)
        self.comparison_panel.pack(fill=tk.BOTH, expand=True)
        
        control_frame = ttk.Frame(self)
        control_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Label(control_frame, text="Select Sequence:").pack(side=tk.LEFT, padx=5)
        
        self.sequence_var = tk.StringVar()
        self.sequence_combo = ttk.Combobox(control_frame, textvariable=self.sequence_var,
                                           state='readonly', width=30)
        self.sequence_combo.pack(side=tk.LEFT, padx=5)
        self.sequence_combo.bind('<<ComboboxSelected>>', self._on_sequence_selected)
        
        ttk.Button(control_frame, text="View MST", command=self._compute_mst).pack(side=tk.RIGHT, padx=5)
    
    def _load_initial_data(self):
        if self.sequences:
            self._update_sequence_combo()
            if self.graph.species:
                self.graph_panel.display_graph(self.graph)
    
    def _update_sequence_combo(self):
        seq_ids = [seq.sequence_id for seq in self.sequences]
        self.sequence_combo['values'] = seq_ids
    
    def _on_sequence_selected(self, event):
        seq_id = self.sequence_var.get()
        seq = self.sequence_library.search(seq_id)
        
        if seq:
            self.nucleotide_viewer.display_sequence(seq)
            self.mutation_panel.display_history(seq)
    
    def _generate_dataset(self):
        from src.models.dataset_generator import generate_datasets, load_datasets
        
        try:
            generate_datasets()
            sequences_data, mutations_data, distances_data = load_datasets()
            
            self.sequences = []
            self.sequence_library = SequenceLibrary()
            
            for seq_data in sequences_data:
                seq = Sequence(
                    seq_data['sequence_id'],
                    seq_data['species_name'],
                    SequenceType[seq_data['sequence_type']]
                )
                for i, base_char in enumerate(seq_data['sequence_string']):
                    seq.insert_nucleotide(i, Base[base_char])
                self.sequences.append(seq)
                self.sequence_library.insert(seq)
            
            self.graph = PhylogeneticGraph()
            for dist_data in distances_data:
                self.graph.add_relationship(
                    dist_data['species_a'],
                    dist_data['species_b'],
                    int(dist_data['distance'])
                )
            
            self._update_sequence_combo()
            self.graph_panel.display_graph(self.graph)
            messagebox.showinfo("Success", "Dataset generated and loaded successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to generate dataset: {str(e)}")
    
    def _load_dataset(self):
        from src.models.dataset_generator import load_datasets
        
        try:
            sequences_data, mutations_data, distances_data = load_datasets()
            
            self.sequences = []
            self.sequence_library = SequenceLibrary()
            
            for seq_data in sequences_data:
                seq = Sequence(
                    seq_data['sequence_id'],
                    seq_data['species_name'],
                    SequenceType[seq_data['sequence_type']]
                )
                for i, base_char in enumerate(seq_data['sequence_string']):
                    seq.insert_nucleotide(i, Base[base_char])
                self.sequences.append(seq)
                self.sequence_library.insert(seq)
            
            self.graph = PhylogeneticGraph()
            for dist_data in distances_data:
                self.graph.add_relationship(
                    dist_data['species_a'],
                    dist_data['species_b'],
                    int(dist_data['distance'])
                )
            
            self._update_sequence_combo()
            self.graph_panel.display_graph(self.graph)
            messagebox.showinfo("Success", "Dataset loaded successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load dataset: {str(e)}")
    
    def _compute_mst(self):
        if not self.graph.species:
            messagebox.showwarning("Warning", "No phylogenetic graph data available!")
            return
        
        mst = self.graph.minimum_spanning_tree()
        self.graph_panel.display_graph(self.graph, highlight_mst=True, mst_edges=mst.edges)
        
        total_weight = mst.get_total_weight()
        messagebox.showinfo("MST Computed", f"MST with {len(mst.edges)} edges\nTotal weight: {total_weight:.1f}")
    
    def _compare_sequences_dialog(self):
        dialog = tk.Toplevel(self)
        dialog.title("Compare Sequences")
        dialog.geometry("500x300")
        
        ttk.Label(dialog, text="Select Sequence 1:").pack(pady=5)
        seq1_var = tk.StringVar()
        seq1_combo = ttk.Combobox(dialog, textvariable=seq1_var,
                                  state='readonly', width=40)
        seq1_combo['values'] = [seq.sequence_id for seq in self.sequences]
        seq1_combo.pack(pady=5)
        
        ttk.Label(dialog, text="Select Sequence 2:").pack(pady=5)
        seq2_var = tk.StringVar()
        seq2_combo = ttk.Combobox(dialog, textvariable=seq2_var,
                                  state='readonly', width=40)
        seq2_combo['values'] = [seq.sequence_id for seq in self.sequences]
        seq2_combo.pack(pady=5)
        
        def compare():
            seq1_id = seq1_var.get()
            seq2_id = seq2_var.get()
            
            seq1 = self.sequence_library.search(seq1_id)
            seq2 = self.sequence_library.search(seq2_id)
            
            if seq1 and seq2:
                self.comparison_panel.compare_sequences(seq1, seq2)
                dialog.destroy()
            else:
                messagebox.showerror("Error", "Please select valid sequences!")
        
        ttk.Button(dialog, text="Compare", command=compare).pack(pady=10)
    
    def _show_about(self):
        messagebox.showinfo("About", "Bioinformatics Analysis Tool\n\n"
                                   "Features:\n"
                                   "- Sequence Viewer (Linked List visualization)\n"
                                   "- Mutation History Panel\n"
                                   "- Phylogenetic Graph with MST\n"
                                   "- Sequence Comparison with Edit Distance")


def run_gui(sequences=None, graph=None):
    app = MainGUI(sequences, graph)
    app.mainloop()