import os
import json
from src.models.sequence import Sequence
from src.models.graph import PhylogeneticGraph
from src.models.edit_distance import compute_edit_distance, traceback, get_alignment_from_stack


def generate_html(sequences=None, graph=None, bst=None, bst_image=None, output_file='visualization.html'):
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write('<!DOCTYPE html>\n')
        f.write('<html lang="en">\n')
        f.write('<head>\n')
        f.write('    <meta charset="UTF-8">\n')
        f.write('    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n')
        f.write('    <title>Bioinformatics Tool</title>\n')
        f.write('<style>\n')
        f.write('        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f0f0f0; }\n')
        f.write('        h1 { text-align: center; color: #333; }\n')
        f.write('        h2 { color: #555; border-bottom: 2px solid #3498db; padding-bottom: 5px; margin-top: 30px; }\n')
        f.write('        .section { background: white; padding: 20px; margin: 15px 0; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }\n')
        f.write('        select { padding: 8px; font-size: 14px; width: 100%; max-width: 400px; }\n')
        f.write('        .nucleotide { display: inline-block; width: 30px; height: 30px; border-radius: 50%; text-align: center; line-height: 30px; color: white; font-weight: bold; margin: 2px; }\n')
        f.write('        .nucleotide.A { background-color: #FF6B6B; }\n')
        f.write('        .nucleotide.T { background-color: #4ECDC4; }\n')
        f.write('        .nucleotide.G { background-color: #45B7D1; }\n')
        f.write('        .nucleotide.C { background-color: #96CEB4; }\n')
        f.write('        .graph-box { position: relative; width: 100%; height: 400px; border: 2px solid #ddd; border-radius: 8px; background: #fafafa; }\n')
        f.write('        .node { position: absolute; padding: 8px 15px; background: #3498db; color: white; border-radius: 6px; font-size: 12px; text-align: center; }\n')
        f.write('        .edge { position: absolute; background: #999; z-index: 1; }\n')
        f.write('        .edge.mst { background: #e74c3c; }\n')
        f.write('        .edge-label { position: absolute; background: white; padding: 2px 8px; border-radius: 10px; font-size: 11px; border: 1px solid #ddd; z-index: 2; }\n')
        f.write('        .stat-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; }\n')
        f.write('        .stat-box { text-align: center; padding: 15px; background: #3498db; color: white; border-radius: 8px; }\n')
        f.write('        .stat-num { font-size: 24px; font-weight: bold; }\n')
        f.write('        .btn { padding: 8px 20px; background: #3498db; color: white; border: none; border-radius: 4px; cursor: pointer; }\n')
        f.write('        .btn:hover { background: #2980b9; }\n')
        f.write('        .distance-result { font-size: 20px; color: #e74c3c; font-weight: bold; }\n')
        f.write('        pre { background: #f8f8f8; padding: 10px; border-radius: 4px; font-family: monospace; }\n')
        f.write('        @media (max-width: 600px) { .stat-grid { grid-template-columns: repeat(2, 1fr); } }\n')
        f.write('</style>\n')
        f.write('</head>\n')
        f.write('<body>\n')
        f.write('    <h1>Bioinformatics Analysis Tool</h1>\n')

        if sequences:
            num_seq = len(sequences)
            num_spec = len(set(s.species_name for s in sequences))
            total_nuc = sum(s.length() for s in sequences)
            total_dist = graph.get_total_weight() if graph else 0
            
            f.write('    <div class="section">\n')
            f.write('        <h2>Dataset Overview</h2>\n')
            f.write('        <div class="stat-grid">\n')
            f.write('            <div class="stat-box"><div class="stat-num">' + str(num_seq) + '</div><div>Sequences</div></div>\n')
            f.write('            <div class="stat-box"><div class="stat-num">' + str(num_spec) + '</div><div>Species</div></div>\n')
            f.write('            <div class="stat-box"><div class="stat-num">' + str(total_nuc) + '</div><div>Nucleotides</div></div>\n')
            f.write('            <div class="stat-box"><div class="stat-num">' + str(total_dist) + '</div><div>Total Distance</div></div>\n')
            f.write('        </div>\n')
            f.write('    </div>\n')

            f.write('    <div class="section">\n')
            f.write('        <h2>Sequence Viewer</h2>\n')
            f.write('        <select id="seq-select" onchange="showSequence()">\n')
            for seq in sequences:
                f.write('            <option value="' + seq.sequence_id + '">' + seq.sequence_id + ' (' + seq.species_name + ')</option>\n')
            f.write('        </select>\n')
            f.write('        <div id="seq-display" style="margin-top: 15px;"></div>\n')
            f.write('        <div id="mutation-history" style="margin-top: 15px;"></div>\n')
            f.write('    </div>\n')

            f.write('    <div class="section">\n')
            f.write('        <h2>Phylogenetic Tree (MST)</h2>\n')
            f.write('        <button class="btn" onclick="toggleMST()">Toggle MST View</button>\n')
            f.write('        <div class="graph-box" id="graph-box"></div>\n')
            f.write('        <div id="mst-info" style="margin-top: 10px; font-size: 14px;"></div>\n')
            f.write('    </div>\n')

            if bst:
                f.write('    <div class="section">\n')
                f.write('        <h2>Sequence Library (BST)</h2>\n')
                if bst_image:
                    f.write('        <img src="' + bst_image + '" alt="BST Visualization" style="max-width: 100%; height: auto; border-radius: 8px;">\n')
                else:
                    f.write('        <div class="graph-box" id="bst-box"></div>\n')
                f.write('    </div>\n')

            f.write('    <div class="section">\n')
            f.write('        <h2>Sequence Comparison</h2>\n')
            f.write('        <div style="margin-bottom: 10px;">\n')
            f.write('            Sequence 1: <select id="seq1-select">\n')
            for seq in sequences:
                f.write('                <option value="' + seq.sequence_id + '">' + seq.sequence_id + '</option>\n')
            f.write('            </select>\n')
            f.write('        </div>\n')
            f.write('        <div style="margin-bottom: 10px;">\n')
            f.write('            Sequence 2: <select id="seq2-select">\n')
            for seq in sequences:
                f.write('                <option value="' + seq.sequence_id + '">' + seq.sequence_id + '</option>\n')
            f.write('            </select>\n')
            f.write('        </div>\n')
            f.write('        <button class="btn" onclick="compareSeqs()">Compare</button>\n')
            f.write('        <div id="compare-result" style="margin-top: 15px;"></div>\n')
            f.write('    </div>\n')

        f.write('    <script>\n')

        if sequences:
            seq_data = []
            for seq in sequences:
                seq_str = seq.get_sequence_string()
                mutations = []
                for m in seq.mutation_history():
                    original = m.original_base.value if m.original_base else '-'
                    new_base = m.new_base.value if m.new_base else '-'
                    mutations.append({
                        'type': m.mutation_type.value,
                        'position': m.position,
                        'original': original,
                        'new': new_base
                    })
                seq_data.append({
                    'id': seq.sequence_id,
                    'string': seq_str,
                    'species': seq.species_name,
                    'mutations': mutations
                })
            
            f.write('var sequences = ' + json.dumps(seq_data) + ';\n\n')
            
            f.write('function showSequence() {\n')
            f.write('    var id = document.getElementById("seq-select").value;\n')
            f.write('    var seq = sequences.find(function(s) { return s.id === id; });\n')
            f.write('    var display = document.getElementById("seq-display");\n')
            f.write('    display.innerHTML = "";\n')
            f.write('    for (var i = 0; i < seq.string.length; i++) {\n')
            f.write('        var base = seq.string[i];\n')
            f.write('        var div = document.createElement("div");\n')
            f.write('        div.className = "nucleotide " + base;\n')
            f.write('        div.textContent = base;\n')
            f.write('        display.appendChild(div);\n')
            f.write('    }\n')
            f.write('    var history = document.getElementById("mutation-history");\n')
            f.write('    if (seq.mutations.length > 0) {\n')
            f.write('        history.innerHTML = "<h4>Mutation History:</h4>";\n')
            f.write('        for (var i = 0; i < seq.mutations.length; i++) {\n')
            f.write('            var m = seq.mutations[i];\n')
            f.write('            history.innerHTML += "<p>" + m.type + ": Pos " + m.position + " (" + m.original + " -> " + m.new + ")</p>";\n')
            f.write('        }\n')
            f.write('    } else {\n')
            f.write('        history.innerHTML = "<p>No mutations</p>";\n')
            f.write('    }\n')
            f.write('}\n\n')
            f.write('showSequence();\n')

        if graph:
            species_list = graph.species
            edges_list = graph.edges
            mst = graph.minimum_spanning_tree()
            
            mst_edge_set = set()
            for edge in mst.edges:
                mst_edge_set.add(edge[0] + '-' + edge[1])
                mst_edge_set.add(edge[1] + '-' + edge[0])
            
            f.write('var species = ' + json.dumps(species_list) + ';\n')
            f.write('var edges = ' + json.dumps(edges_list) + ';\n')
            f.write('var mstEdges = new Set(' + json.dumps(list(mst_edge_set)) + ');\n')
            f.write('var showMSTOnly = true;\n')
            f.write('var mstCount = ' + str(len(mst.edges)) + ';\n')
            f.write('var mstWeight = ' + str(mst.get_total_weight()) + ';\n\n')
            
            f.write('function drawGraph() {\n')
            f.write('    var box = document.getElementById("graph-box");\n')
            f.write('    box.innerHTML = "";\n')
            f.write('    var width = box.offsetWidth;\n')
            f.write('    var height = box.offsetHeight;\n')
            f.write('    var positions = {};\n')
            f.write('    var centerX = width / 2;\n')
            f.write('    var centerY = height / 2;\n')
            f.write('    var radius = Math.min(width, height) / 3;\n')
            f.write('    for (var i = 0; i < species.length; i++) {\n')
            f.write('        var angle = (i / species.length) * Math.PI * 2 - Math.PI / 2;\n')
            f.write('        positions[species[i]] = {\n')
            f.write('            x: centerX + radius * Math.cos(angle),\n')
            f.write('            y: centerY + radius * Math.sin(angle)\n')
            f.write('        };\n')
            f.write('    }\n')
            f.write('    for (var i = 0; i < species.length; i++) {\n')
            f.write('        var s = species[i];\n')
            f.write('        var node = document.createElement("div");\n')
            f.write('        node.className = "node";\n')
            f.write('        node.textContent = s;\n')
            f.write('        node.style.left = (positions[s].x - 50) + "px";\n')
            f.write('        node.style.top = (positions[s].y - 15) + "px";\n')
            f.write('        box.appendChild(node);\n')
            f.write('    }\n')
            f.write('    for (var i = 0; i < edges.length; i++) {\n')
            f.write('        var edge = edges[i];\n')
            f.write('        var isMST = mstEdges.has(edge[0] + "-" + edge[1]);\n')
            f.write('        if (!showMSTOnly || isMST) {\n')
            f.write('            var x1 = positions[edge[0]].x;\n')
            f.write('            var y1 = positions[edge[0]].y;\n')
            f.write('            var x2 = positions[edge[1]].x;\n')
            f.write('            var y2 = positions[edge[1]].y;\n')
            f.write('            var len = Math.sqrt(Math.pow(x2-x1,2) + Math.pow(y2-y1,2));\n')
            f.write('            var angle = Math.atan2(y2-y1, x2-x1) * 180 / Math.PI;\n')
            f.write('            var line = document.createElement("div");\n')
            f.write('            line.className = "edge" + (isMST ? " mst" : "");\n')
            f.write('            line.style.left = x1 + "px";\n')
            f.write('            line.style.top = y1 + "px";\n')
            f.write('            line.style.width = len + "px";\n')
            f.write('            line.style.height = (isMST ? "3px" : "2px");\n')
            f.write('            line.style.transformOrigin = "left center";\n')
            f.write('            line.style.transform = "rotate(" + angle + "deg)";\n')
            f.write('            box.appendChild(line);\n')
            f.write('            var label = document.createElement("div");\n')
            f.write('            label.className = "edge-label";\n')
            f.write('            label.textContent = edge[2];\n')
            f.write('            label.style.left = ((x1+x2)/2 - 10) + "px";\n')
            f.write('            label.style.top = ((y1+y2)/2 - 15) + "px";\n')
            f.write('            box.appendChild(label);\n')
            f.write('        }\n')
            f.write('    }\n')
            f.write('}\n\n')
            
            f.write('function toggleMST() {\n')
            f.write('    showMSTOnly = !showMSTOnly;\n')
            f.write('    drawGraph();\n')
            f.write('}\n\n')
            
            f.write('drawGraph();\n')
            f.write('document.getElementById("mst-info").innerHTML = "MST: " + mstCount + " edges, Total Weight: " + mstWeight;\n')

        if bst:
            bst_data = bst.to_dict()
            f.write('var bstData = ' + json.dumps(bst_data) + ';\n\n')
            
            f.write('function drawBST() {\n')
            f.write('    var box = document.getElementById("bst-box");\n')
            f.write('    box.innerHTML = "";\n')
            f.write('    var width = box.offsetWidth;\n')
            f.write('    var height = box.offsetHeight;\n')
            f.write('    var nodeWidth = 80;\n')
            f.write('    var nodeHeight = 35;\n')
            f.write('    \n')
            f.write('    function layout(node, x, y, levelWidth) {\n')
            f.write('        if (!node) return [];\n')
            f.write('        var nodes = [{id: node.id, x: x, y: y}];\n')
            f.write('        var edges = [];\n')
            f.write('        var nextLevelWidth = levelWidth / 2;\n')
            f.write('        if (node.left) {\n')
            f.write('            var leftResult = layout(node.left, x - nextLevelWidth, y + 60, nextLevelWidth);\n')
            f.write('            nodes = nodes.concat(leftResult.nodes);\n')
            f.write('            edges.push({x1: x, y1: y + nodeHeight/2, x2: x - nextLevelWidth, y2: y + 60 - nodeHeight/2});\n')
            f.write('            edges = edges.concat(leftResult.edges);\n')
            f.write('        }\n')
            f.write('        if (node.right) {\n')
            f.write('            var rightResult = layout(node.right, x + nextLevelWidth, y + 60, nextLevelWidth);\n')
            f.write('            nodes = nodes.concat(rightResult.nodes);\n')
            f.write('            edges.push({x1: x, y1: y + nodeHeight/2, x2: x + nextLevelWidth, y2: y + 60 - nodeHeight/2});\n')
            f.write('            edges = edges.concat(rightResult.edges);\n')
            f.write('        }\n')
            f.write('        return {nodes: nodes, edges: edges};\n')
            f.write('    }\n')
            f.write('    \n')
            f.write('    var result = layout(bstData, width / 2, 30, width / 3);\n')
            f.write('    \n')
            f.write('    for (var i = 0; i < result.edges.length; i++) {\n')
            f.write('        var e = result.edges[i];\n')
            f.write('        var line = document.createElement("div");\n')
            f.write('        line.className = "edge";\n')
            f.write('        line.style.left = e.x1 + "px";\n')
            f.write('        line.style.top = e.y1 + "px";\n')
            f.write('        var len = Math.sqrt(Math.pow(e.x2-e.x1,2) + Math.pow(e.y2-e.y1,2));\n')
            f.write('        var angle = Math.atan2(e.y2-e.y1, e.x2-e.x1) * 180 / Math.PI;\n')
            f.write('        line.style.width = len + "px";\n')
            f.write('        line.style.height = "2px";\n')
            f.write('        line.style.transformOrigin = "left center";\n')
            f.write('        line.style.transform = "rotate(" + angle + "deg)";\n')
            f.write('        box.appendChild(line);\n')
            f.write('    }\n')
            f.write('    \n')
            f.write('    for (var i = 0; i < result.nodes.length; i++) {\n')
            f.write('        var n = result.nodes[i];\n')
            f.write('        var node = document.createElement("div");\n')
            f.write('        node.className = "node";\n')
            f.write('        node.textContent = n.id;\n')
            f.write('        node.style.left = (n.x - nodeWidth/2) + "px";\n')
            f.write('        node.style.top = (n.y) + "px";\n')
            f.write('        node.style.width = nodeWidth + "px";\n')
            f.write('        node.style.height = nodeHeight + "px";\n')
            f.write('        node.style.lineHeight = nodeHeight + "px";\n')
            f.write('        node.style.fontSize = "11px";\n')
            f.write('        box.appendChild(node);\n')
            f.write('    }\n')
            f.write('}\n\n')
            
            f.write('drawBST();\n')

        if sequences:
            edit_distance_data = {}
            for i, seq1 in enumerate(sequences):
                for j, seq2 in enumerate(sequences):
                    if i != j:
                        dp = compute_edit_distance(seq1, seq2)
                        dist, stack = traceback(seq1, seq2, dp)
                        aligned_a, aligned_b, ops = get_alignment_from_stack(stack)
                        edit_distance_data[seq1.sequence_id + '-' + seq2.sequence_id] = {
                            'distance': dist,
                            'aligned_a': aligned_a,
                            'aligned_b': aligned_b,
                            'operations': ops
                        }
            
            f.write('var editDistances = ' + json.dumps(edit_distance_data) + ';\n\n')
            
            f.write('function compareSeqs() {\n')
            f.write('    var id1 = document.getElementById("seq1-select").value;\n')
            f.write('    var id2 = document.getElementById("seq2-select").value;\n')
            f.write('    var result = document.getElementById("compare-result");\n')
            f.write('    if (id1 === id2) {\n')
            f.write('        result.innerHTML = "<p>Please select different sequences</p>";\n')
            f.write('        return;\n')
            f.write('    }\n')
            f.write('    var data = editDistances[id1 + "-" + id2] || editDistances[id2 + "-" + id1];\n')
            f.write('    var markers = "";\n')
            f.write('    for (var i = 0; i < data.aligned_a.length; i++) {\n')
            f.write('        if (data.aligned_a[i] === data.aligned_b[i]) markers += "|";\n')
            f.write('        else markers += "*";\n')
            f.write('    }\n')
            f.write('    result.innerHTML = "<div class=\'distance-result\'>Edit Distance: " + data.distance + "</div>";\n')
            f.write('    result.innerHTML += "<pre>" + data.aligned_a + "</pre>";\n')
            f.write('    result.innerHTML += "<pre>" + markers + "</pre>";\n')
            f.write('    result.innerHTML += "<pre>" + data.aligned_b + "</pre>";\n')
            f.write('}\n')

        f.write('    </script>\n')
        f.write('</body>\n')
        f.write('</html>')

    print("HTML visualization saved to: " + output_file)
    return output_file