class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):#入栈
        self.items.append(item)#放末尾，也就是栈顶

    def pop(self):#出栈，返回栈顶
        if not self.is_empty():
            return self.items.pop()
        return None

    def peek(self):#只看栈顶，不删
        if not self.is_empty():
            return self.items[-1]
        return None

    def is_empty(self):
        return len(self.items) == 0

    def get_all(self):
        return self.items.copy()