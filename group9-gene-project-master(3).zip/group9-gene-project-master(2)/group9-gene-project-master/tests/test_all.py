import unittest
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.models.sequence import Sequence
from src.models.enums import Base, SequenceType, MutationType
from src.models.mutation import Mutation
from src.models.bst import SequenceLibrary
from src.models.graph import PhylogeneticGraph
from src.models.edit_distance import compute_edit_distance, traceback, get_alignment_from_stack
from src.models.dataset_generator import generate_datasets, load_datasets


class TestSequenceMethods(unittest.TestCase):
    def test_get_sequence_string(self):
        seq = Sequence("test_seq", "TestSpecies", SequenceType.DNA)
        bases = [Base.A, Base.T, Base.G, Base.C]
        
        for i, base in enumerate(bases):
            seq.insert_nucleotide(i, base)
        
        self.assertEqual(seq.get_sequence_string(), "ATGC")
    
    def test_reverse_complement(self):
        seq = Sequence("test_seq", "TestSpecies", SequenceType.DNA)
        seq.insert_nucleotide(0, Base.A)
        seq.insert_nucleotide(1, Base.T)
        seq.insert_nucleotide(2, Base.G)
        seq.insert_nucleotide(3, Base.C)
        
        rc = seq.reverse_complement()
        self.assertEqual(rc.get_sequence_string(), "GCAT")
        
        seq2 = Sequence("test_seq2", "TestSpecies", SequenceType.DNA)
        seq2.insert_nucleotide(0, Base.A)
        seq2.insert_nucleotide(1, Base.A)
        seq2.insert_nucleotide(2, Base.T)
        seq2.insert_nucleotide(3, Base.T)
        rc2 = seq2.reverse_complement()
        self.assertEqual(rc2.get_sequence_string(), "AATT")
        
        seq3 = Sequence("test_seq3", "TestSpecies", SequenceType.DNA)
        seq3.insert_nucleotide(0, Base.G)
        seq3.insert_nucleotide(1, Base.C)
        seq3.insert_nucleotide(2, Base.G)
        rc3 = seq3.reverse_complement()
        self.assertEqual(rc3.get_sequence_string(), "CGC")
    
    def test_mutation_undo(self):
        seq = Sequence("test_seq", "TestSpecies", SequenceType.DNA)
        seq.insert_nucleotide(0, Base.A)
        seq.insert_nucleotide(1, Base.T)
        seq.insert_nucleotide(2, Base.G)
        seq.insert_nucleotide(3, Base.C)
        
        original = seq.get_sequence_string()
        
        m1 = Mutation(MutationType.SUBSTITUTION, 1, new_base=Base.G)
        seq.apply_mutation(m1)
        
        m2 = Mutation(MutationType.INSERTION, 2, new_base=Base.A)
        seq.apply_mutation(m2)
        
        seq.undo_last_mutation()
        seq.undo_last_mutation()
        
        self.assertEqual(seq.get_sequence_string(), original)


class TestBSTMethods(unittest.TestCase):
    def test_in_order_traversal(self):
        lib = SequenceLibrary()
        
        seq3 = Sequence("seq003", "Species3", SequenceType.DNA)
        seq1 = Sequence("seq001", "Species1", SequenceType.DNA)
        seq2 = Sequence("seq002", "Species2", SequenceType.DNA)
        seq5 = Sequence("seq005", "Species5", SequenceType.DNA)
        seq4 = Sequence("seq004", "Species4", SequenceType.DNA)
        
        lib.insert(seq3)
        lib.insert(seq1)
        lib.insert(seq2)
        lib.insert(seq5)
        lib.insert(seq4)
        
        result = lib.in_order_traversal()
        ids = [s.sequence_id for s in result]
        
        self.assertEqual(ids, ["seq001", "seq002", "seq003", "seq004", "seq005"])
    
    def test_search(self):
        lib = SequenceLibrary()
        
        seq1 = Sequence("seq001", "Species1", SequenceType.DNA)
        seq2 = Sequence("seq002", "Species2", SequenceType.DNA)
        
        lib.insert(seq1)
        lib.insert(seq2)
        
        found = lib.search("seq001")
        self.assertIsNotNone(found)
        self.assertEqual(found.sequence_id, "seq001")
        
        not_found = lib.search("seq999")
        self.assertIsNone(not_found)


class TestPhylogeneticGraph(unittest.TestCase):
    def test_get_neighbors(self):
        graph = PhylogeneticGraph()
        
        graph.add_species("Human")
        graph.add_species("Chimp")
        graph.add_species("Gorilla")
        graph.add_species("Orangutan")
        
        graph.add_relationship("Human", "Chimp", 2.5)
        graph.add_relationship("Human", "Gorilla", 5.0)
        graph.add_relationship("Chimp", "Gorilla", 4.8)
        graph.add_relationship("Gorilla", "Orangutan", 8.7)
        
        human_neighbors = graph.get_neighbors("Human")
        self.assertIn("Chimp", human_neighbors)
        self.assertIn("Gorilla", human_neighbors)
        self.assertEqual(len(human_neighbors), 2)
        
        gorilla_neighbors = graph.get_neighbors("Gorilla")
        self.assertIn("Human", gorilla_neighbors)
        self.assertIn("Chimp", gorilla_neighbors)
        self.assertIn("Orangutan", gorilla_neighbors)
        self.assertEqual(len(gorilla_neighbors), 3)
    
    def test_minimum_spanning_tree(self):
        graph = PhylogeneticGraph()
        
        species = ["A", "B", "C", "D"]
        for s in species:
            graph.add_species(s)
        
        graph.add_relationship("A", "B", 1)
        graph.add_relationship("A", "C", 3)
        graph.add_relationship("A", "D", 4)
        graph.add_relationship("B", "C", 2)
        graph.add_relationship("B", "D", 5)
        graph.add_relationship("C", "D", 1)
        
        mst = graph.minimum_spanning_tree()
        
        self.assertEqual(len(mst.edges), len(species) - 1)
        self.assertEqual(set(mst.species), set(species))


class TestEditDistance(unittest.TestCase):
    def test_edit_distance_identity(self):
        seq1 = Sequence("seq1", "Species1", SequenceType.DNA)
        seq2 = Sequence("seq2", "Species2", SequenceType.DNA)
        
        for base_char in "ATGC":
            seq1.insert_nucleotide(seq1.size, Base[base_char])
            seq2.insert_nucleotide(seq2.size, Base[base_char])
        
        dp = compute_edit_distance(seq1, seq2)
        distance, _ = traceback(seq1, seq2, dp)
        self.assertEqual(distance, 0)
    
    def test_edit_distance_substitution(self):
        seq1 = Sequence("seq1", "Species1", SequenceType.DNA)
        seq2 = Sequence("seq2", "Species2", SequenceType.DNA)
        
        for base_char in "ATGC":
            seq1.insert_nucleotide(seq1.size, Base[base_char])
        
        for base_char in "AAGC":
            seq2.insert_nucleotide(seq2.size, Base[base_char])
        
        dp = compute_edit_distance(seq1, seq2)
        distance, _ = traceback(seq1, seq2, dp)
        self.assertEqual(distance, 1)
    
    def test_edit_distance_insertion(self):
        seq1 = Sequence("seq1", "Species1", SequenceType.DNA)
        seq2 = Sequence("seq2", "Species2", SequenceType.DNA)
        
        for base_char in "ATG":
            seq1.insert_nucleotide(seq1.size, Base[base_char])
        
        for base_char in "ATGC":
            seq2.insert_nucleotide(seq2.size, Base[base_char])
        
        dp = compute_edit_distance(seq1, seq2)
        distance, _ = traceback(seq1, seq2, dp)
        self.assertEqual(distance, 1)
    
    def test_edit_distance_deletion(self):
        seq1 = Sequence("seq1", "Species1", SequenceType.DNA)
        seq2 = Sequence("seq2", "Species2", SequenceType.DNA)
        
        for base_char in "ATGC":
            seq1.insert_nucleotide(seq1.size, Base[base_char])
        
        for base_char in "ATG":
            seq2.insert_nucleotide(seq2.size, Base[base_char])
        
        dp = compute_edit_distance(seq1, seq2)
        distance, _ = traceback(seq1, seq2, dp)
        self.assertEqual(distance, 1)
    
    def test_alignment_length(self):
        seq1 = Sequence("seq1", "Species1", SequenceType.DNA)
        seq2 = Sequence("seq2", "Species2", SequenceType.DNA)
        
        for base_char in "ATGC":
            seq1.insert_nucleotide(seq1.size, Base[base_char])
        
        for base_char in "AAGC":
            seq2.insert_nucleotide(seq2.size, Base[base_char])
        
        dp = compute_edit_distance(seq1, seq2)
        _, stack = traceback(seq1, seq2, dp)
        aligned_a, aligned_b, _ = get_alignment_from_stack(stack)
        
        self.assertEqual(len(aligned_a), len(aligned_b))
        self.assertEqual(len(aligned_a), max(seq1.length(), seq2.length()))


class TestDatasetGenerator(unittest.TestCase):
    def test_generate_and_load_datasets(self):
        output_dir = 'test_datasets'
        
        sequences, mutations, distances = generate_datasets(output_dir)
        
        self.assertGreaterEqual(len(sequences), 10)
        self.assertGreaterEqual(len(mutations), 15)
        self.assertGreaterEqual(len(distances), 10)
        
        loaded_seqs, loaded_muts, loaded_dists = load_datasets(output_dir)
        
        self.assertEqual(len(loaded_seqs), len(sequences))
        self.assertEqual(len(loaded_muts), len(mutations))
        self.assertEqual(len(loaded_dists), len(distances))
        
        import shutil
        if os.path.exists(output_dir):
            shutil.rmtree(output_dir)


if __name__ == "__main__":
    unittest.main()